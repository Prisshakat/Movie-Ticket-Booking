CREATE DATABASE IF NOT EXISTS ticketdb;
USE ticketdb;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  email VARCHAR(100),
  password_hash VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS movie (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  language VARCHAR(50),
  rating VARCHAR(10),
  poster_url VARCHAR(500)
);

CREATE TABLE IF NOT EXISTS show_time (
  id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT,
  screen VARCHAR(50),
  start_at DATETIME,
  total_seats INT,
  seats_available INT,
  price DECIMAL(10,2),
  FOREIGN KEY (movie_id) REFERENCES movie(id)
);

CREATE TABLE IF NOT EXISTS booking (
  id INT AUTO_INCREMENT PRIMARY KEY,
  show_time_id INT,
  user_email VARCHAR(120),
  quantity INT,
  amount DECIMAL(10,2),
  booked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (show_time_id) REFERENCES show_time(id)
);
